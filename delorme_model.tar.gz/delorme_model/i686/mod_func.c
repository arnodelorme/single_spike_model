#include <stdio.h>
#include "hocdec.h"
modl_reg(){
	NOT_PARALLEL_SUB(fprintf(stderr, "Additional mechanisms from files\n");)

fprintf(stderr," expsyn3.mod");
fprintf(stderr, "\n");
_expsyn3_reg();
}
